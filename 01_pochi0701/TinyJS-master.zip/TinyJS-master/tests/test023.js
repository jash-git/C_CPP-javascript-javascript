// mikael.kindborg@mobilesorcery.com - Function symbol is evaluated in bracket-less body of false if-statement
var foo; // a var is only created automated by assignment

if (foo !== undefined) foo();

result = 1;
