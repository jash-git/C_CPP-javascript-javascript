// simple for loop
var a = 0;
var i;
for (i=1;i<10;i++) a = a + i;
result = a==45;
