// simple function
function add(x,y) { return x+y; }
result = add(3,6)==9;
