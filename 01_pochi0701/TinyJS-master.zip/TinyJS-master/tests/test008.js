// functions in variables
var bob = {};
bob.add = function(x,y) { return x+y; };

result = bob.add(3,6)==9;
