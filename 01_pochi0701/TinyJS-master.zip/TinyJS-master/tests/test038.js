// simple for loop containing initialisation, using +=
var a = 0;
var i = 1;
while(i<10){
   if(i==3)break;
   a += i;
   i += 1;
}
result = a==3;
