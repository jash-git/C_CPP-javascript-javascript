// test for ternary

result = (true?3:4)==3 && (false?5:6)==6;
