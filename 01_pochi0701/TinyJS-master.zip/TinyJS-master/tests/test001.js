// simply testing we can return the correct value
result = 1;
