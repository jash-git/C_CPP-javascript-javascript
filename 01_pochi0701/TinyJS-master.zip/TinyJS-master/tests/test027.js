// test for postincrement working as expected
var foo = 5;
result = (foo++)==5;
