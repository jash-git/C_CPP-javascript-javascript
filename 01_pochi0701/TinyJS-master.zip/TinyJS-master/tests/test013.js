// if .. else with blocks
var a = 42;
if (a != 42) {
   result = 0;
} else {
  result = 1;
}
