#ifndef DEFINEH
#ifndef __linux
#define DEFINEH
#define write _write
#define read _read
#define close _close
#define lseek _lseek
#define open _open
#define unlink _unlink
#define strcmpi _strcmpi
#define chdir _chdir
#define stricmp _stricmp
#define getcwd _getcwd
#define mkdir _mkdir
#define strncmpi _strncmpi
#define access _access
#define strnicmp _strnicmp
#define rmdir _rmdir
#define strdup _strdup
#endif
#endif
