# JavaScriptInterpreter
A JavaScript Interpreter built in C++ with Qt.
<br/><br/>
<img src="https://github.com/HerikLyma/JavaScriptInterpreter/blob/master/JavaScriptInterpreter/images/JavaScriptInterpreter.png"/>
