// comparison
var a = 42;
result = a==42;
