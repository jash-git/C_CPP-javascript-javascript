// functions in variables using JSON-style initialisation
var bob = { add : function(x,y) { return x+y; } };

result = bob.add(3,6)==9;
