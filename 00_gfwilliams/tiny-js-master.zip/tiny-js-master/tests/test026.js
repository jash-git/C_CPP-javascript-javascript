// check for undefined-ness
a = undefined;
b = "foo";
result = a==undefined && b!=undefined;
