// simple if
var a = 42;
if (a < 43)
  result = 1;
