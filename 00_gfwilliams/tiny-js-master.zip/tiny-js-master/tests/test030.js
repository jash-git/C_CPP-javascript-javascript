// test for array join
var a = [1,2,4,5,7];

result = a.join(",")=="1,2,4,5,7";
